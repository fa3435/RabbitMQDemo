package ty.rabbitmq.send;

import java.io.IOException;
import com.rabbitmq.client.ConnectionFactory;
import com.rabbitmq.client.Connection;
import com.rabbitmq.client.Channel;
import com.rabbitmq.client.MessageProperties;

public class EmitLogTopic {

	private static final String EXCHANGE_NAME = "topic_logs";

    public static void main(String[] argv)
                  throws Exception {

        ConnectionFactory factory = new ConnectionFactory();
        factory.setHost("192.168.30.161");
        factory.setUsername("test_user");
        factory.setPassword("123456");
        Connection connection = factory.newConnection();
        Channel channel = connection.createChannel();
        channel.exchangeDeclare(EXCHANGE_NAME, "topic");
        argv = new String[]{"kern.iems","keys.critical","keys2.critical"};
        String[] messages = new String[]{"kankan","133@","李发亮"};
        for(int i=0;i<3;i++){
        	String arg = argv[i];
        	String message = messages[i];
        	System.out.println(arg);
//        	channel.
        	channel.basicPublish(EXCHANGE_NAME, arg,MessageProperties.PERSISTENT_TEXT_PLAIN, message.getBytes());
            System.out.println(" [x] Sent '" + arg + "':'" + message + "'");
        }                                      
        connection.close();
    }
    
   
}
